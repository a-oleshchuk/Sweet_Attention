# Product Catalog

## Summary
AstraLearn offers live group lessons for language, STEM, literacy, and enrichment programs.
Monthly and quarterly plans are available depending on the course line.

## Product Notes
- English programs are certificate-eligible and are common in access and billing cases.
- Math programs drive many plan-change and school-support scenarios.
- Python Basics for Kids is a premium STEM offer.
- SAT Math Prep is the highest-priced plan and often creates downgrade requests.

## Related Data
- `data/core/courses.csv`
- `data/billing/subscriptions.csv`
