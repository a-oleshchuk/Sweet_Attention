# Demo Scenarios

## Summary
These curated cases are intended for demos and evaluation.

## Scenario 1: Paid but no access
- Guardian: G0001
- Student: S0001
- Subscription: SUB0001
- Agent path: `payments.csv` -> `user_access.csv` -> `policies/BILLING.md`

## Scenario 2: Duplicate charge and refund
- Guardian: G0002
- Student: S0002
- Subscription: SUB0002
- Agent path: `invoices.csv` -> `payments.csv` -> `refunds.csv` -> `policies/REFUNDS.md`

## Scenario 3: Missing receipt for reimbursement
- Guardian: G0003
- Student: S0003
- Subscription: SUB0003
- Agent path: `invoices.csv` -> `how_to/INVOICES.md`

## Scenario 4: Pause active lessons
- Guardian: G0004
- Student: S0004
- Subscription: SUB0004
- Agent path: `subscriptions.csv` -> `lessons.csv` -> `policies/SUBSCRIPTIONS.md`

## Scenario 5: Missed lesson recovery
- Guardian: G0005
- Student: S0005
- Subscription: SUB0005
- Agent path: `lessons.csv` -> `attendance.csv` -> `policies/LESSONS.md`

## Scenario 6: Password reset and duplicate profile
- Guardian: G0006
- Student: S0006
- Subscription: SUB0006
- Agent path: `user_access.csv` -> `how_to/PASSWORD_RESET.md` -> `policies/ACCESS.md`

## Scenario 7: Plan downgrade request
- Guardian: G0007
- Student: S0007
- Subscription: SUB0007
- Agent path: `subscriptions.csv` -> `courses.csv` -> `policies/SUBSCRIPTIONS.md`

## Scenario 8: Trial refund
- Guardian: G0008
- Student: S0008
- Subscription: SUB0008
- Agent path: `payments.csv` -> `attendance.csv` -> `refunds.csv` -> `policies/REFUNDS.md`
