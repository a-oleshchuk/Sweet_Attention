# Dataset Overview

## Summary
This document explains what each CSV file represents and how the files relate to one another.

## Core Tables
- `guardians.csv`: the paying adult account and contact profile
- `students.csv`: the child profile linked to the guardian
- `courses.csv`: the course catalog and pricing attributes
- `user_access.csv`: current website access and security state

## Billing Tables
- `subscriptions.csv`: purchased plan, billing cycle, and renewal state
- `payments.csv`: payment attempts and outcomes
- `invoices.csv`: issued billing documents and receipt flags
- `refunds.csv`: processed or approved refunds

## Learning and Support Tables
- `enrollments.csv`: course placement and teacher assignment
- `lessons.csv`: lesson schedule and delivery details
- `attendance.csv`: actual participation details
- `support_tickets.csv`: support history, routing, and resolution outcomes
