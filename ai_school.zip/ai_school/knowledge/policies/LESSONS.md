# Lesson Operations Policy

## Summary
This document covers reschedules, no-shows, recordings, and makeup expectations.

## Rules
1. A live lesson may be rescheduled without penalty if the request arrives at least 6 hours before the lesson start.
2. A same-day no-show does not guarantee a makeup lesson, but the recording should be offered when available.
3. Trial lessons may be moved once without extra approval.
4. Recordings are normally posted within 12 hours after an attended or recorded lesson.
5. Repeated no-shows may trigger an outreach workflow from Academic Operations.

## Related Data
- `data/learning/lessons.csv`
- `data/learning/attendance.csv`
- `data/learning/enrollments.csv`

## Example Cases
- Missed lesson recovery: verify whether the student no-showed or attended before promising a makeup path.
- Recording issue: confirm lesson status and elapsed time since lesson completion.
