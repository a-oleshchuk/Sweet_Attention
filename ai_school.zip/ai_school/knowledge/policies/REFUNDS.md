# Refunds Policy

## Summary
This document defines which billing events can be refunded and which cases require escalation.

## Rules
1. Duplicate successful charges for the same invoice must be refunded in full to the original payment method.
2. Families who cancel within the first 14 calendar days may receive a full refund if fewer than two lessons were attended.
3. Partial goodwill refunds up to 50 percent may be granted for service issues such as repeated teacher replacement.
4. Any chargeback case must be escalated before a manual refund is processed.

## Related Data
- `data/billing/payments.csv`
- `data/billing/refunds.csv`
- `data/learning/attendance.csv`

## Example Cases
- Duplicate charge: two successful payments tied to one invoice, followed by one processed refund.
- Trial refund: refund is allowed only after attendance is checked against the trial threshold.
