# Subscription Changes Policy

## Summary
This document covers upgrades, downgrades, pauses, and cancel-at-period-end flows.

## Rules
1. Plan upgrades can take effect immediately if billing is recalculated for the current cycle.
2. Plan downgrades apply on the next renewal date unless Support Ops approves an urgent exception.
3. A subscription pause may last between 7 and 30 days and preserves the student seat.
4. Cancel-at-period-end should keep access active until the paid period ends.
5. Paused subscriptions should show an `on_hold` portal state rather than expired access.

## Related Data
- `data/billing/subscriptions.csv`
- `data/learning/lessons.csv`
- `data/core/user_access.csv`

## Example Cases
- Pause request: check upcoming lessons and confirm the next renewal date.
- Downgrade request: explain that the current plan remains active until the next billing cycle starts.
