# Billing Policy

## Summary
This document defines how AstraLearn bills subscriptions, retries failed payments, and restores access after successful charges.

## Rules
1. Invoices are issued at the start of each billing period and are due within 48 hours.
2. Failed payments keep access active for a 72-hour grace period unless fraud checks or manual risk review block the account.
3. Successful payments should update student entitlement within 15 minutes.
4. If payment succeeds but entitlement stays inactive after 15 minutes, support may trigger manual access restoration.
5. Receipts are sent automatically after successful payment unless the invoice is marked `receipt_sent = no`.

## Related Data
- `data/billing/invoices.csv`
- `data/billing/payments.csv`
- `data/core/user_access.csv`

## Example Cases
- Paid but no access: verify a successful payment, then inspect `portal_status` in `user_access.csv`.
- Missing receipt: verify invoice status is `paid` and receipt flag is pending before offering resend.
