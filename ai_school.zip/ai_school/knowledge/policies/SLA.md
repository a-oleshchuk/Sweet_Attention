# Support SLA and Escalation Policy

## Summary
This document defines ticket priority, first-response targets, and routing ownership.

## Priority Guide
- High: paid access blocked, duplicate charge, account locked before a live lesson
- Medium: pause requests, invoice questions, plan changes, missed lesson follow-up
- Low: navigation help, profile updates, general product questions

## Ownership
- Billing Operations owns duplicate charges, refunds, and paid-no-access sync cases.
- Platform Support owns password resets, login failures, and profile merge issues.
- Academic Operations owns lesson scheduling, recordings, and attendance disputes.
- Retention owns pauses, downgrades, and cancel-at-period-end requests.

## SLA Targets
1. High priority first response in 15 minutes during support hours.
2. Medium priority first response in 2 hours.
3. Low priority first response within 1 business day.
