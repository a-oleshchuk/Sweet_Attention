# Access and Security Policy

## Summary
This document defines how support handles login failures, password resets, duplicate profiles, and billing-linked access issues.

## Rules
1. Password reset links remain valid for 30 minutes.
2. Duplicate child profiles must be merged rather than deleted immediately.
3. Access locks tied to payment mismatch require billing verification before the student portal is re-enabled.
4. Student usernames are system-generated and should not be edited manually by support.
5. The guardian account is the source of truth for linked student profiles.

## Related Data
- `data/core/guardians.csv`
- `data/core/students.csv`
- `data/core/user_access.csv`
- `data/billing/payments.csv`

## Example Cases
- Password reset plus duplicate profile: first guide the reset flow, then explain the merge workflow.
- Paid but blocked: billing must confirm the payment before student entitlement is changed.
