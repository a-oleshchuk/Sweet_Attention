# How To Join and Manage Lessons

## Summary
This guide explains how the family uses the lesson area of the website.

## Steps
1. Open Lessons from the parent portal.
2. Select Upcoming to see meeting links and lesson times.
3. Use Reschedule at least 6 hours before the lesson start to move the class.
4. Use Recordings to replay a past lesson once processing is complete.
5. Review Homework after each completed lesson.

## Troubleshooting
- Same-day no-shows normally receive recording access rather than a guaranteed makeup lesson.
- Trial lessons can be rescheduled once.
