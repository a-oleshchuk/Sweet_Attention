# How To Find Invoices and Receipts

## Summary
This guide explains how a parent finds billing documents and updates payment information.

## Steps
1. Open Billing in the parent portal.
2. Select Invoice History to see issued invoices.
3. Click Download PDF for invoice copies.
4. Open a paid invoice and select Receipt to download payment confirmation.
5. Update the default card before the next renewal if needed.

## Troubleshooting
- If a paid invoice has no receipt button, support should check `receipt_sent` in `invoices.csv`.
- Corporate reimbursement requests usually need both the invoice and receipt.
