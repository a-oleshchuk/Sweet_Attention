# How To Reset Password and Manage Profiles

## Summary
This guide explains the standard login recovery flow and what to do if a child profile looks wrong.

## Steps
1. Open the sign-in page and choose Forgot Password.
2. Enter the guardian email address and confirm the reset email.
3. Open the email within 30 minutes and create a new password.
4. After sign-in, open Students to check linked profiles.
5. If a child is missing or duplicated, contact support instead of creating another account.

## Troubleshooting
- The guardian account is the source of truth for linked student profiles.
- Duplicate profiles require a merge workflow rather than manual deletion.
