# Parent Portal Basics

## Summary
This guide explains the main parent flows inside the website.

## Steps
1. Sign in with the guardian email used during checkout.
2. Open Dashboard to view active students, upcoming lessons, and billing alerts.
3. Use Students to switch child profiles.
4. Use Lessons to join classes, review recordings, and view homework.
5. Use Billing to download invoices, update payment methods, and check renewal timing.

## Related Data
- `data/core/guardians.csv`
- `data/core/students.csv`
- `data/core/user_access.csv`
