# Knowledge Index

This folder is the canonical markdown knowledge base for the AI school MVP.
Every topic lives in a single markdown file inside its category folder.

## Policies
- `policies/BILLING.md`: billing lifecycle, autopay, paid-but-no-access handling
- `policies/REFUNDS.md`: duplicate charges, trial refunds, goodwill rules
- `policies/SUBSCRIPTIONS.md`: upgrades, downgrades, pauses, cancellations
- `policies/ACCESS.md`: login, password reset, profile merge, entitlement checks
- `policies/LESSONS.md`: no-shows, recordings, reschedules, makeup expectations
- `policies/SLA.md`: priority rules, ownership, escalation paths

## How-to
- `how_to/PORTAL_BASICS.md`: dashboard navigation and main parent flows
- `how_to/INVOICES.md`: finding invoices, receipts, and payment methods
- `how_to/LESSONS.md`: joining lessons, rescheduling, checking recordings
- `how_to/PASSWORD_RESET.md`: resetting password and managing student profiles

## Reference Docs
- `docs/PRODUCT_CATALOG.md`: product and pricing overview
- `docs/DATASET_OVERVIEW.md`: explanation of CSV tables and linked data
- `docs/DEMO_SCENARIOS.md`: curated demo cases with concrete IDs

## Snapshot
- guardians: 52
- students: 69
- subscriptions: 69
- support tickets: 84
