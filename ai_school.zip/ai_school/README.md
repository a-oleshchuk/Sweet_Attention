# AI School Mock Knowledge Base

This folder contains a realistic offline dataset for the online-school support MVP.
It is designed for retrieval, reasoning, and demo flows without live integrations.

Structure:
- knowledge/README.md
- knowledge/policies/*.md
- knowledge/how_to/*.md
- knowledge/docs/*.md
- data/core/
- data/billing/
- data/learning/
- data/support/

Snapshot sizes:
- guardians: 52
- students: 69
- user_access: 121
- courses: 12
- subscriptions: 69
- invoices: 254
- payments: 250
- refunds: 14
- enrollments: 69
- lessons: 369
- attendance: 258
- support_tickets: 84

Regenerate with:
..\..\.venv\Scripts\python .\scripts\generate_ai_school_assets.py
